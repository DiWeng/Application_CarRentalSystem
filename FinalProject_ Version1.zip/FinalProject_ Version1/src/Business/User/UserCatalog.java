/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.User;

import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class UserCatalog {
    
    private ArrayList<User> userList;
    private int ct;

    public int getCt() {
        return ct;
    }

    public void setCt(int ct) {
        this.ct = ct;
    }
    
    public UserCatalog() {
        userList = new ArrayList<>();
        ct=1;
    }

    public ArrayList<User> getUserList() {
        return userList;
    }
    
    public User createUser(String name){
        User user = new User();
        user.setName(name);
        userList.add(user);
        ct++;
        return user;
        
    }
}