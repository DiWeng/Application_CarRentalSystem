/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CarRentalSystem;

import Business.AccountRole.AdminAccountRole;
import Business.AdminAccount.AdminAccount;
import Business.User.User;
import Business.User.UserCatalog;

/**
 *
 * @author biubiu
 */
public class ConfigureCarRentalSystem {
    
    public static CarRentalSystem configure(){
        
        CarRentalSystem system = CarRentalSystem.getInstance();
        
        //create agency or private provider
        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        

        //Employee employee = system.getEmployeeDirectory().createEmployee("RRH");
        User user = new UserCatalog().createUser("admin1");
        AdminAccount adminAccount = system.getAdminAccountCatalog().createAdminAccount("admin1", "admin1", user , new AdminAccountRole());
        

        return system;
    }
    
}
