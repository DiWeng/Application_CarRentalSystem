/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CarRentalSystem;

import Business.AdminAccount.AdminAccountCatalog;
import Business.AgencyAccount.AgencyAccountCatalog;
import Business.AgencyAccount.CarCatalog;
import Business.CustomerAccount.CustomerAccountCatalog;
import Business.AgencyAccount.OrderCatalog;
import Business.AgencyAccount.ParkingLocationCatalog;
import Business.PrivateProviderAccount.PrivateProviderAccountCatalog;
import Business.User.UserCatalog;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class CarRentalSystem {
    private static CarRentalSystem business;
    private final String name = "CarRentalSystem";
    //private WorkQueue workQueue;
    private AdminAccountCatalog adminAccountCatalog;
    private AgencyAccountCatalog agencyAccountCatalog;
    private CustomerAccountCatalog cusomerAccountCatalog;
    private PrivateProviderAccountCatalog privateProviderAccountCatalog;
    private OrderCatalog orderCatalog;
    private CarCatalog carCatalog;
    private UserCatalog userCatalog;
    private ParkingLocationCatalog parkingLocationCatalog;

    public ParkingLocationCatalog getParkingLocationCatalog() {
        return parkingLocationCatalog;
    }

    public void setParkingLocationCatalog(ParkingLocationCatalog parkingLocationCatalog) {
        this.parkingLocationCatalog = parkingLocationCatalog;
    }

    public static CarRentalSystem getBusiness() {
        
        return business;
    }

    public static void setBusiness(CarRentalSystem business) {
        CarRentalSystem.business = business;
    }

    public UserCatalog getUserCatalog() {
        return userCatalog;
    }

    public void setUserCatalog(UserCatalog userCatalog) {
        this.userCatalog = userCatalog;
    }
    
    public static CarRentalSystem getInstance(){
        if(business==null){
            System.out.println("bbb");
            business=new CarRentalSystem();
        }
        return business;
    }
    
    public CarRentalSystem(){
        adminAccountCatalog = new AdminAccountCatalog();
        agencyAccountCatalog = new AgencyAccountCatalog();
        cusomerAccountCatalog= new CustomerAccountCatalog();
        privateProviderAccountCatalog = new PrivateProviderAccountCatalog();
        if(parkingLocationCatalog==null){
            parkingLocationCatalog=new ParkingLocationCatalog();
        }
        if(orderCatalog==null){
            orderCatalog = new OrderCatalog();
        }
        if(carCatalog==null){
            carCatalog = new CarCatalog(); 
        }
        
        if(userCatalog==null){
            userCatalog=new UserCatalog();
        }
    }
    

    public AdminAccountCatalog getAdminAccountCatalog() {
        return adminAccountCatalog;
    }

    public void setAdminAccountCatalog(AdminAccountCatalog adminAccountCatalog) {
        this.adminAccountCatalog = adminAccountCatalog;
    }

    public AgencyAccountCatalog getAgencyAccountCatalog() {
        return agencyAccountCatalog;
    }

    public void setAgencyAccountCatalog(AgencyAccountCatalog agencyAccountCatalog) {
        this.agencyAccountCatalog = agencyAccountCatalog;
    }

    public CustomerAccountCatalog getCusomerAccountCatalog() {
        return cusomerAccountCatalog;
    }

    public void setCusomerAccountCatalog(CustomerAccountCatalog cusomerAccountCatalog) {
        this.cusomerAccountCatalog = cusomerAccountCatalog;
    }

    public PrivateProviderAccountCatalog getPrivateProviderAccountCatalog() {
        return privateProviderAccountCatalog;
    }

    public void setPrivateProviderAccountCatalog(PrivateProviderAccountCatalog privateProviderAccountCatalog) {
        this.privateProviderAccountCatalog = privateProviderAccountCatalog;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(OrderCatalog orderCatalog) {
        this.orderCatalog = orderCatalog;
    }

    public CarCatalog getCarCatalog() {
        return carCatalog;
    }

    public void setCarCatalog(CarCatalog carCatalog) {
        this.carCatalog = carCatalog;
    }
   
    
    
}
