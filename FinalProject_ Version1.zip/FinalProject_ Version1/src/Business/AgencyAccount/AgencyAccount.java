/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import Business.User.User;
import Business.AccountRole.Role;

/**
 *
 * @author erin
 */
public class AgencyAccount {
    
    private String agencyUserName;
    private String agencyPassword;
    private User user;
    private Role role;
    private ParkingLocationCatalog parkingLocationCatalog;
    private OrderCatalog orderCatalog;
    //private WorkQueue workQueue;
    

    public AgencyAccount() {
        //workQueue = new WorkQueue();
        this.parkingLocationCatalog = new ParkingLocationCatalog();
        this.orderCatalog = new OrderCatalog();
    }

    public ParkingLocationCatalog getParkingLocationCatalog() {
        return parkingLocationCatalog;
    }

    public void setParkingLocationCatalog(ParkingLocationCatalog parkingLocationCatalog) {
        this.parkingLocationCatalog = parkingLocationCatalog;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(OrderCatalog orderCatalog) {
        this.orderCatalog = orderCatalog;
    }
    
    public String getAgencyUserName() {
        return agencyUserName;
    }

    public void setAgencyUserName(String agencyUserName) {
        this.agencyUserName = agencyUserName;
    }

    public String getAgencyPassword() {
        return agencyPassword;
    }

    public void setAgencyPassword(String agencyPassword) {
        this.agencyPassword = agencyPassword;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
   
    
    public Car searchcarbyorder(int ordernum){
        for(ParkingLocation pl:this.getParkingLocationCatalog().getParkingLocationList()){
            for(Car c: pl.getCarCatalog().getCarList()){
                for(Business.Order.Order o:c.getOrdercatalog().getOrderList()){
                    if (o.getOrderId()==ordernum){
                        return c;
                    }
                }
            }
        }
        return null;
    }
    
    
    @Override
    public String toString() {
        return agencyUserName;
    }
    
}
