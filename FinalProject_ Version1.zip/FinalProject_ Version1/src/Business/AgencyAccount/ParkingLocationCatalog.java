/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class ParkingLocationCatalog {
    
    private ArrayList<ParkingLocation> parkingLocationList;
    private int ct;

    public int getCt() {
        return ct;
    }

    public void setCt(int ct) {
        this.ct = ct;
    }
    
    
    public ParkingLocationCatalog(){
        this.parkingLocationList = new ArrayList<ParkingLocation>();
        ct=1;
    }

    public ArrayList<ParkingLocation> getParkingLocationList() {
        return parkingLocationList;
    }

    public void setParkingLocationList(ArrayList<ParkingLocation> parkingLocationList) {
        this.parkingLocationList = parkingLocationList;
    }

    public ParkingLocation addParkingLocation(){
        ParkingLocation p = new ParkingLocation();
        this.parkingLocationList.add(p);
        ct++;
        return p;
    }
    
    public void removeAirplane(ParkingLocation p){
        this.parkingLocationList.remove(p);
    }
}
