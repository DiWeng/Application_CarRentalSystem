/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

/**
 *
 * @author biubiu
 */
public class Car {
    
    private int carId;
    private String carBrand;
    private String carModel;
    private String carColor="NA";
    private int carMilage=0;
    private boolean carAvailability;
    public static int count = 1;
    private int price=0;
    private String capacity="0";
    private String LicensePlate="NA";
    private OrderCatalog ordercatalog;
    private boolean instock;
    private boolean canbedrive;
    private int agencyId;
    private int parkingLocationId;
    private String zipCode;

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public int getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(int agencyId) {
        this.agencyId = agencyId;
    }

    public int getParkingLocationId() {
        return parkingLocationId;
    }

    public void setParkingLocationId(int parkingLocationId) {
        this.parkingLocationId = parkingLocationId;
    }


    public boolean isInstock() {
        return instock;
    }

    public void setInstock(boolean instock) {
        this.instock = instock;
    }

    public boolean isCanbedrive() {
        return canbedrive;
    }

    public void setCanbedrive(boolean canbedrive) {
        this.canbedrive = canbedrive;
    }

    public OrderCatalog getOrdercatalog() {
        return ordercatalog;
    }

    public void setOrdercatalog(OrderCatalog ordercatalog) {
        this.ordercatalog = ordercatalog;
    }

    public String getLicensePlate() {
        return LicensePlate;
    }

    public void setLicensePlate(String LicensePlate) {
        this.LicensePlate = LicensePlate;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public Car() {
        carId = count;
        count++;
        this.carAvailability = true;
        ordercatalog=new OrderCatalog();
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Car.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    public Car placeOrder(){
        this.carAvailability = false;
        return this;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String carColor) {
        this.carColor = carColor;
    }

    public int getCarMilage() {
        return carMilage;
    }

    public void setCarMilage(int carMilage) {
        this.carMilage = carMilage;
    }

    public boolean isCarAvailability() {
        return carAvailability;
    }

    public void setCarAvailability(boolean carAvailability) {
        this.carAvailability = carAvailability;
    }
    
    @Override
    public String toString(){
        return String.valueOf(carId);
    }
   
}
