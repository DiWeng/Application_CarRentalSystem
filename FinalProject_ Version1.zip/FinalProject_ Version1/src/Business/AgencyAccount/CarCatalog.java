/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class CarCatalog {
    private ArrayList<Car> carList;
    private int ct;

    public int getCt() {
        return ct;
    }

    public void setCt(int ct) {
        this.ct = ct;
    }
    
    public CarCatalog(){
        carList = new ArrayList<Car>();
        ct=1;
    }

    public ArrayList<Car> getCarList() {
        return carList;
    }

    public void setCarList(ArrayList<Car> carList) {
        this.carList = carList;
    }
    
    public Car addCar(){
        Car car = new Car();
        this.carList.add(car);
        ct++;
        return car;
    }
    
    public void removeCar(Car car){
        this.carList.remove(car);
    }
}
