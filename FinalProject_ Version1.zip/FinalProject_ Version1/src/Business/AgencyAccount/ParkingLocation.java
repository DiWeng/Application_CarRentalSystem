/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

/**
 *
 * @author biubiu
 */
public class ParkingLocation {
    
    private int parkingLocationId;
    private String zipCode;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String province;
    private String country;
    private CarCatalog carCatalog;
    private static int count = 1;
    
    public ParkingLocation(){
        parkingLocationId = count;
        count++;
        this.carCatalog = new CarCatalog();
    }

    public int getParkingLocationId() {
        return parkingLocationId;
    }

    public void setParkingLocationId(int parkingLocationId) {
        this.parkingLocationId = parkingLocationId;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public CarCatalog getCarCatalog() {
        return carCatalog;
    }

    public void setCarCatalog(CarCatalog carCatalog) {
        this.carCatalog = carCatalog;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        ParkingLocation.count = count;
    }
    
    @Override
    public String toString(){
        return String.valueOf(parkingLocationId);
    }
    
}
