/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.PrivateProviderAccount;
import Business.AccountRole.PrivateProviderAccountRole;
import Business.User.User;
import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class PrivateProviderAccountCatalog {
    
    private ArrayList<PrivateProviderAccount> privateProviderAccountList;

    public PrivateProviderAccountCatalog() {
        privateProviderAccountList = new ArrayList<>();
    }

    public ArrayList<PrivateProviderAccount> getPrivateProviderAccountList() {
        return privateProviderAccountList;
    }
    
    public PrivateProviderAccount authenticateUser(String username, String password){
        for (PrivateProviderAccount pa : privateProviderAccountList)
            if (pa.getUsername().equals(username) && pa.getPassword().equals(password)){
                return pa;
            }
        return null;
    }
    
    public PrivateProviderAccount createPrivateProviderAccount(String username, String password, User user, PrivateProviderAccountRole privateProviderAccountRole){
        PrivateProviderAccount privateProviderAccount = new PrivateProviderAccount();
        privateProviderAccount.setUsername(username);
        privateProviderAccount.setPassword(password);
        privateProviderAccount.setUser(user);
        privateProviderAccount.setRole(privateProviderAccountRole);
        privateProviderAccountList.add(privateProviderAccount);
        return privateProviderAccount;
    }
    
}
