/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AdminAccount;

import Business.AccountRole.AdminAccountRole;
import Business.User.User;
import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class AdminAccountCatalog {
    
    private ArrayList<AdminAccount> userAccountList;

    public AdminAccountCatalog() {
        userAccountList = new ArrayList<>();
    }

    public ArrayList<AdminAccount> getAdminAccountList() {
        return userAccountList;
    }
    
    public AdminAccount authenticateUser(String username, String password){
        for (AdminAccount ua : userAccountList)
            if (ua.getUsername().equals(username) && ua.getPassword().equals(password)){
                return ua;
            }
        return null;
    }
    
    public AdminAccount createAdminAccount(String username, String password, User user, AdminAccountRole adminAccountRole){
        AdminAccount userAccount = new AdminAccount();
        userAccount.setUsername(username);
        userAccount.setPassword(password);
        userAccount.setUser(user);
        userAccount.setRole(adminAccountRole);
        userAccountList.add(userAccount);
        return userAccount;
    }
}
