/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AdminAccount;

import Business.User.User;
import Business.AccountRole.Role;
//import Business.WorkQueue.WorkQueue;

/**
 *
 * @author raunak
 */
public class AdminAccount {
    
    private String username;
    private String password;
    private User user;
    private Role role;
   // private WorkQueue workQueue;

    public AdminAccount() {
        //workQueue = new WorkQueue();
    }
    
    
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public User getUser() {
        return user;
    }

//    public WorkQueue getWorkQueue() {
//        return workQueue;
//    }

    
    
    @Override
    public String toString() {
        return username;
    }
    
    
    
}