/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AccountRole;

import Business.Organization.Organization;
import Business.AdminAccount.AdminAccount;
import Business.CarRentalSystem.CarRentalSystem;
import javax.swing.JPanel;

/**
 *
 * @author biubiu
 */
public class AgencyAccountRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, AdminAccount account, Organization organization, CarRentalSystem carRentalSystem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
