/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AccountRole;

import Business.Organization.Organization;
import Business.AdminAccount.AdminAccount;
import Business.CarRentalSystem.CarRentalSystem;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public abstract class Role {
    
    public enum RoleType{
        AgencyAccount("Agency Account"),
        PrivateProviderAccount("Private Provider Account"),
        CustomerAccount("Customer Account");
        
        private String value;
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, AdminAccount account, Organization organization, CarRentalSystem carRentalSystem);

    @Override
    public String toString() {
        return this.getClass().getName();
    }
    
    
}