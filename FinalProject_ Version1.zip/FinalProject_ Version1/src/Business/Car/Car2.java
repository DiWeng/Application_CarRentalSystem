/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Car;

/**
 *
 * @author biubiu
 */
public class Car2 {
    private int carId;
    private String carBrand;
    private String carModel;
    private String carColor;
    private int carMilage;
    private boolean carAvailability;
    private static int count = 1;
    private int price;
    private int agencyId;
    private int parkingLocationId;
    private int zipCode;

    public Car2() {
        carId = count;
        count++;
        this.carAvailability = true;
    }

    public int getZipCode() {
        return zipCode;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public int getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(int agencyId) {
        this.agencyId = agencyId;
    }

    public int getParkingLocationId() {
        return parkingLocationId;
    }

    public void setParkingLocationId(int parkingLocationId) {
        this.parkingLocationId = parkingLocationId;
    }

    
    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Business.AgencyAccount.Car.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    public Car2 placeOrder(){
        this.carAvailability = false;
        return this;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String carColor) {
        this.carColor = carColor;
    }

    public int getCarMilage() {
        return carMilage;
    }

    public void setCarMilage(int carMilage) {
        this.carMilage = carMilage;
    }

    public boolean isCarAvailability() {
        return carAvailability;
    }

    public void setCarAvailability(boolean carAvailability) {
        this.carAvailability = carAvailability;
    }
}
