/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.AccountRole.AgencyAccountRole;
import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class AgencyOrganization extends Organization{

    public AgencyOrganization() {
        super(Organization.Type.Agency.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new AgencyAccountRole());
        return roles;
    }
     
}