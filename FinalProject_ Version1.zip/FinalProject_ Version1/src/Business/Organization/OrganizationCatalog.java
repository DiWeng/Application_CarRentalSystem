/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class OrganizationCatalog {
    
    private ArrayList<Organization> organizationList;

    public OrganizationCatalog() {
        organizationList = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.Agency.getValue())){
            organization = new AgencyOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.PrivateProvider.getValue())){
            organization = new PrivateProviderOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Customer.getValue())){
            organization = new CustomerOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
}