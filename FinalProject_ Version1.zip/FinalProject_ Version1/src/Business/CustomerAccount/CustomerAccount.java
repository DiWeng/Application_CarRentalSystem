/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CustomerAccount;

import Business.User.User;
import Business.AccountRole.Role;
import Business.AgencyAccount.Car;
import Business.AgencyAccount.ParkingLocation;
import Business.Order.Order;
import javax.swing.ImageIcon;

/**
 *
 * @author biubiu
 */
public class CustomerAccount {
    
    private String customerUserName;
    private String customerPassword;
    private User user;
    private Role role;
    //private WorkQueue workQueue;
    private String LicenseNum;
    private String email;
    private boolean custstatus;
    private ImageIcon icon;

    public ImageIcon getIcon() {
        return icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }
    
    

    public boolean getCuststatus() {
        return custstatus;
    }

    public void setCuststatus(boolean custstatus) {
        this.custstatus = custstatus;
    }
    
    

    public String getLicenseNum() {
        return LicenseNum;
    }

    public void setLicenseNum(String LicenseNum) {
        this.LicenseNum = LicenseNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CustomerAccount() {
        //workQueue = new WorkQueue();
    }

    public String getCustomerUserName() {
        return customerUserName;
    }

    public void setCustomerUserName(String customerUserName) {
        this.customerUserName = customerUserName;
    }

    public String getCustomerPassword() {
        return customerPassword;
    }

    public void setCustomerPassword(String customerPassword) {
        this.customerPassword = customerPassword;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    
    
    
    
   
    @Override
    public String toString() {
        return customerUserName;
    }
    
    
    
}
