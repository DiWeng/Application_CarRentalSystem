/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Network;

import Business.Enterprise.EnterpriseDirectory;

/**
 *
 * @author biubiu
 */

public class Network {
    private String name;
    private EnterpriseDirectory enterpriseDirectory;
    
    public Network(){
        enterpriseDirectory=new EnterpriseDirectory();
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EnterpriseDirectory getEnterpriseDirectory() {
        return enterpriseDirectory;
    }
    
    @Override
    public String toString(){
        return name;
    }
//    private String name;
//    private AdminAccountCatalog adminAccountCatalog;
//    private AgencyAccountCatalog agencyAccountCatalog;
//    private CustomerAccountCatalog cusomerAccountCatalog;
//    private PrivateProviderAccountCatalog privateProviderAccountCatalog;
//    private OrderCatalog orderCatalog;
//    private CarCatalog carCatalog;
//    private UserCatalog userCatalog;
//    private ParkingLocationCatalog parkingLocationCatalog;
//    
//    public Network(){
//        enterpriseDirectory=new EnterpriseDirectory();
//        adminAccountCatalog = new AdminAccountCatalog();
//        agencyAccountCatalog = new AgencyAccountCatalog();
//        cusomerAccountCatalog= new CustomerAccountCatalog();
//        privateProviderAccountCatalog = new PrivateProviderAccountCatalog();
//        orderCatalog = new OrderCatalog();
//        carCatalog = new CarCatalog();
//        userCatalog = new UserCatalog();
//        parkingLocationCatalog = new ParkingLocationCatalog();
//    }
//    
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public AdminAccountCatalog getAdminAccountCatalog() {
//        return adminAccountCatalog;
//    }
//
//    public void setAdminAccountCatalog(AdminAccountCatalog adminAccountCatalog) {
//        this.adminAccountCatalog = adminAccountCatalog;
//    }
//
//    public AgencyAccountCatalog getAgencyAccountCatalog() {
//        return agencyAccountCatalog;
//    }
//
//    public void setAgencyAccountCatalog(AgencyAccountCatalog agencyAccountCatalog) {
//        this.agencyAccountCatalog = agencyAccountCatalog;
//    }
//
//    public CustomerAccountCatalog getCusomerAccountCatalog() {
//        return cusomerAccountCatalog;
//    }
//
//    public void setCusomerAccountCatalog(CustomerAccountCatalog cusomerAccountCatalog) {
//        this.cusomerAccountCatalog = cusomerAccountCatalog;
//    }
//
//    public PrivateProviderAccountCatalog getPrivateProviderAccountCatalog() {
//        return privateProviderAccountCatalog;
//    }
//
//    public void setPrivateProviderAccountCatalog(PrivateProviderAccountCatalog privateProviderAccountCatalog) {
//        this.privateProviderAccountCatalog = privateProviderAccountCatalog;
//    }
//
//    public OrderCatalog getOrderCatalog() {
//        return orderCatalog;
//    }
//
//    public void setOrderCatalog(OrderCatalog orderCatalog) {
//        this.orderCatalog = orderCatalog;
//    }
//
//    public CarCatalog getCarCatalog() {
//        return carCatalog;
//    }
//
//    public void setCarCatalog(CarCatalog carCatalog) {
//        this.carCatalog = carCatalog;
//    }
//
//    public UserCatalog getUserCatalog() {
//        return userCatalog;
//    }
//
//    public void setUserCatalog(UserCatalog userCatalog) {
//        this.userCatalog = userCatalog;
//    }
//
//    public ParkingLocationCatalog getParkingLocationCatalog() {
//        return parkingLocationCatalog;
//    }
//
//    public void setParkingLocationCatalog(ParkingLocationCatalog parkingLocationCatalog) {
//        this.parkingLocationCatalog = parkingLocationCatalog;
//    }
//    
//    
//
//    public EnterpriseDirectory getEnterpriseDirectory() {
//        return enterpriseDirectory;
//    }
//    
//    @Override
//    public String toString(){
//        return name;
//    }
    
}
