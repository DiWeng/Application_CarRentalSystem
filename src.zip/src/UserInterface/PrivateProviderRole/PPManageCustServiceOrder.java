/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.PrivateProviderRole;

import Business.AgencyAccount.Car;
import Business.AgencyAccount.ParkingLocation;
import Business.Order.Order;
import Business.PrivateProviderAccount.PrivateProviderAccount;
import UserInterface.CarRentalAgencyRole.CustServiceDept.*;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author shirleycai
 */
public class PPManageCustServiceOrder extends javax.swing.JPanel {

    /**
     * Creates new form MangeCustServiceOrder
     */
    JPanel UserProcessContainer;
    PrivateProviderAccount ppa;
    public PPManageCustServiceOrder(JPanel UserProcessContainer,PrivateProviderAccount ppa) {
        this.ppa=ppa;
        this.UserProcessContainer=UserProcessContainer;
        initComponents();
        populateTable();
    }
    
    public void populateTable(){
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        model.setRowCount(0);
        for(ParkingLocation pl:ppa.getParkingLocationCatalog().getParkingLocationList()){
            for(Car c:pl.getCarCatalog().getCarList()){
                for(Order o:c.getOrdercatalog().getOrderList()){
                    if(o.getOrderStatus().equalsIgnoreCase("returned")){
                    Object[] row = new Object[2];
                    row[0]=o;
                    row[1]=c;
                    //row[2] = o.getOrderStatus();
            
                    model.addRow(row);
                }
                    
                }
            }
        }
        
        
        
        DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel(); 
        model2.setRowCount(0);
        List<Order> orderL=new ArrayList<>();
        for(ParkingLocation pl:ppa.getParkingLocationCatalog().getParkingLocationList()){
            for(Car c:pl.getCarCatalog().getCarList()){
                for(Order o:c.getOrdercatalog().getOrderList()){
                    if(o.getOrderStatus().equals("ready")){
                        orderL.add(o);                      
                }
                    
                }
            }
        }  
        Collections.sort(orderL,new Comparator<Order>(){
            @Override
            public int compare(Order o1,Order o2){
                return o1.getEndingTime()-o2.getEndingTime();
            }
        });
        for(Order o:orderL){
            Object[] row = new Object[2];
            row[0]=o;
            row[1]=ppa.searchcarbyorder(o.getOrderId());
            //row[2] = o.getOrderStatus();
            
            model2.addRow(row);
        }
    }
    
    public void refreshTable(){
        int rowCount = jTable1.getRowCount();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        for(int i=rowCount-1;i>=0;i--) {
            model.removeRow(i);
        }
        
        int rowCount2 = jTable2.getRowCount();
        DefaultTableModel model2 = (DefaultTableModel)jTable2.getModel();
        for(int i=rowCount2-1;i>=0;i--) {
            model2.removeRow(i);
        }
        
        for(ParkingLocation pl:ppa.getParkingLocationCatalog().getParkingLocationList()){
            for(Car c:pl.getCarCatalog().getCarList()){
                for(Order o:c.getOrdercatalog().getOrderList()){
                    if(o.getOrderStatus().equalsIgnoreCase("returned")){
                    Object[] row = new Object[2];
                    row[0]=o;
                    row[1]=c;
                    //row[2] = o.getOrderStatus();
            
                    model.addRow(row);
                }
                    
                }
            }
        }
        
        
        
        
        List<Order> orderL=new ArrayList<>();
        for(ParkingLocation pl:ppa.getParkingLocationCatalog().getParkingLocationList()){
            for(Car c:pl.getCarCatalog().getCarList()){
                for(Order o:c.getOrdercatalog().getOrderList()){
                    if(o.getOrderStatus().equals("ready")){
                        orderL.add(o);                      
                }
                    
                }
            }
        }  
        Collections.sort(orderL,new Comparator<Order>(){
            @Override
            public int compare(Order o1,Order o2){
                return o1.getEndingTime()-o2.getEndingTime();
            }
        });
        for(Order o:orderL){
            Object[] row = new Object[2];
            row[0]=o;
            row[1]=ppa.searchcarbyorder(o.getOrderId());
            //row[2] = o.getOrderStatus();
            
            model2.addRow(row);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        detailbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        backbtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setBackground(new java.awt.Color(140, 199, 181));

        detailbtn.setText("Details(Lower Box)");
        detailbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailbtnActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Order ID", "Car ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Order ID", "Car ID"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel2.setText("Returned");

        jLabel3.setText("Ready to pick up: (Check every 15 minutes)");

        jButton1.setText("Details(Upper Box)");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("RefreshTable");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 295, Short.MAX_VALUE)
                                .addComponent(detailbtn)))
                        .addGap(75, 75, 75))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton2)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(detailbtn)
                    .addComponent(backbtn))
                .addGap(25, 25, 25))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        // TODO add your handling code here:
        UserProcessContainer.remove(this);
        CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
        layout.previous(UserProcessContainer);
    }//GEN-LAST:event_backbtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();
        if(row<0){
            JOptionPane.showMessageDialog(null,"Please select a row from the table first", "Warning", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Order o = (Order)jTable1.getValueAt(row,0);
        Car c=ppa.searchcarbyorder(o.getOrderId());
        
            PPCustServiceJPanel pmcj = new PPCustServiceJPanel(UserProcessContainer, o,c);
            UserProcessContainer.add("PPCustServiceJPanel", pmcj);
            CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
            layout.next(UserProcessContainer);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void detailbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailbtnActionPerformed
        // TODO add your handling code here:
        int row = jTable2.getSelectedRow();
        if(row<0){
            JOptionPane.showMessageDialog(null,"Please select a row from the table first", "Warning", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Order o = (Order)jTable2.getValueAt(row,0);
        Car c=ppa.searchcarbyorder(o.getOrderId());
        
            PPCustServiceJPanel pmcj = new PPCustServiceJPanel(UserProcessContainer, o,c);
            UserProcessContainer.add("PPCustServiceJPanel", pmcj);
            CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
            layout.next(UserProcessContainer);
    }//GEN-LAST:event_detailbtnActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        refreshTable();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn;
    private javax.swing.JButton detailbtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
