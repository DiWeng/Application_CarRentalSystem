/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.AdminRole;

import Business.AgencyAccount.AgencyAccount;
import Business.AgencyAccount.AgencyAccountCatalog;
import Business.CarRentalSystem.CarRentalSystem;
import Business.CarRentalSystem.Network;
import Business.CustomerAccount.CustomerAccount;
import Business.CustomerAccount.CustomerAccountCatalog;

import Business.Organization.Organization;
import Business.PrivateProviderAccount.PrivateProviderAccount;
import Business.PrivateProviderAccount.PrivateProviderAccountCatalog;
import java.awt.CardLayout;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 *
 * @author shirleycai
 */
public class AdminWorkAreaJPanel extends javax.swing.JPanel {

    /**
     * Creates new form AdminWorkAreaJPanel
     */
    JPanel UserProcessContainer;
    CarRentalSystem crs;
    
    public AdminWorkAreaJPanel(JPanel UserProcessContainer,CarRentalSystem crs) {
        this.UserProcessContainer=UserProcessContainer;
        this.crs=crs;       
        initComponents();
        populateTree();
    }

    public void populateTree(){
        DefaultTreeModel model=(DefaultTreeModel)jTree.getModel();
        ArrayList<Network> networkList=crs.getNetworkList();
        
//        ArrayList<Enterprise> enterpriseList;
//        ArrayList<Organization> organizationList;
        
        ArrayList<AgencyAccount> aaList;
        ArrayList<PrivateProviderAccount> ppaList;
        ArrayList<CustomerAccount> caList;
//        AgencyAccountCatalog aaList;
//        PrivateProviderAccountCatalog ppaList;
//        CustomerAccountCatalog caList;
        
//        Network network;
//        Enterprise enterprise;
//        Organization organization;
        
        Network nt;
        AgencyAccount aa;
        PrivateProviderAccount ppa;
        CustomerAccount ca;
        
//        DefaultMutableTreeNode networks=new DefaultMutableTreeNode("Networks");
//        DefaultMutableTreeNode root=(DefaultMutableTreeNode)model.getRoot();
//        root.removeAllChildren();
//        root.insert(networks, 0);
//        
//        DefaultMutableTreeNode networkNode;
//        DefaultMutableTreeNode enterpriseNode;
//        DefaultMutableTreeNode organizationNode;
        
        DefaultMutableTreeNode networks=new DefaultMutableTreeNode("Networks");
        DefaultMutableTreeNode root=(DefaultMutableTreeNode)model.getRoot();
        root.removeAllChildren();
        root.insert(networks, 0);
        
        DefaultMutableTreeNode networkNode;
        DefaultMutableTreeNode aaNode;
        DefaultMutableTreeNode ppaNode;
        DefaultMutableTreeNode caNode;
        
        for(int i=0;i<networkList.size();i++){
            nt=networkList.get(i);
            networkNode=new DefaultMutableTreeNode(nt.getName());
            networks.insert(networkNode, i);
        
            aaList=nt.getAgencyAccountCatalog().getAgencyAccountList();
            for(int j=0; j<aaList.size();j++){
                aa=aaList.get(j);
                aaNode=new DefaultMutableTreeNode(aa.getAgencyUserName());
                networkNode.insert(aaNode, j);
            }
            
            ppaList=nt.getPrivateProviderAccountCatalog().getPrivateProviderAccountList();
            for(int j=0; j<ppaList.size();j++){
                ppa=ppaList.get(j);
                ppaNode=new DefaultMutableTreeNode(ppa.getUsername());
                networkNode.insert(ppaNode, j);
            }
            
            caList=nt.getCusomerAccountCatalog().getCustomerAccountList();
            for(int j=0; j<caList.size();j++){
                ca=caList.get(j);
                caNode=new DefaultMutableTreeNode(ca.getCustomerUserName());
                networkNode.insert(caNode, j);
            }
            
        }
        model.reload();
    }
        
//        for(int i=0;i<networkList.size();i++){
//            network=networkList.get(i);
//            networkNode=new DefaultMutableTreeNode(network.getName());
//            networks.insert(networkNode, i);
//            
//            enterpriseList=network.getEnterpriseDirectory().getEnterpriseList();
//            for(int j=0; j<enterpriseList.size();j++){
//                enterprise=enterpriseList.get(j);
//                enterpriseNode=new DefaultMutableTreeNode(enterprise.getName());
//                networkNode.insert(enterpriseNode, j);
//                
//                organizationList=enterprise.getOrganizationDirectory().getOrganizationList();
//                for(int k=0;k<organizationList.size();k++){
//                    organization=organizationList.get(i);
//                    organizationNode=new DefaultMutableTreeNode(organization.getName());
//                    enterpriseNode.insert(organizationNode, k);
//                }
//            }
//        }
//        model.reload();
//    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree = new javax.swing.JTree();
        jPanel2 = new javax.swing.JPanel();
        btnManageNetwork = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblSelectedNode = new javax.swing.JLabel();
        custbtn = new javax.swing.JButton();
        privatebtn = new javax.swing.JButton();
        orderbtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        agencybtn = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(182, 194, 154));

        jTree.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                jTreeValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jTree);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 158, Short.MAX_VALUE))
        );

        jSplitPane1.setLeftComponent(jPanel1);

        jPanel2.setBackground(new java.awt.Color(230, 206, 172));

        btnManageNetwork.setText("Manage Network");
        btnManageNetwork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageNetworkActionPerformed(evt);
            }
        });

        jLabel1.setText("Selected Node:");

        lblSelectedNode.setText("<View_selected_node>");

        custbtn.setText("Manage Customer");
        custbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                custbtnActionPerformed(evt);
            }
        });

        privatebtn.setText("Manage Private Provider");
        privatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                privatebtnActionPerformed(evt);
            }
        });

        orderbtn.setText("Manage Order");
        orderbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderbtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("System Adminstration Work Area");

        agencybtn.setText("Manage Car Rental Agency");
        agencybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agencybtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(71, Short.MAX_VALUE)
                        .addComponent(jLabel2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(custbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(agencybtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(orderbtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(privatebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnManageNetwork, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblSelectedNode)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(37, 37, 37))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectedNode)
                    .addComponent(jLabel1))
                .addGap(32, 32, 32)
                .addComponent(btnManageNetwork)
                .addGap(14, 14, 14)
                .addComponent(agencybtn)
                .addGap(18, 18, 18)
                .addComponent(privatebtn)
                .addGap(18, 18, 18)
                .addComponent(custbtn)
                .addGap(18, 18, 18)
                .addComponent(orderbtn)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jSplitPane1.setRightComponent(jPanel2);

        add(jSplitPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void jTreeValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_jTreeValueChanged

        DefaultMutableTreeNode selectedNode= (DefaultMutableTreeNode)jTree.getLastSelectedPathComponent();
        if(selectedNode!=null){
            lblSelectedNode.setText(selectedNode.toString());
        }
    }//GEN-LAST:event_jTreeValueChanged

    private void btnManageNetworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageNetworkActionPerformed
        ManageNetworkJPanel manageNetworkJPanel=new ManageNetworkJPanel(UserProcessContainer, crs);
        UserProcessContainer.add("manageNetworkJPanel",manageNetworkJPanel);
        CardLayout layout=(CardLayout)UserProcessContainer.getLayout();
        layout.next(UserProcessContainer);
    }//GEN-LAST:event_btnManageNetworkActionPerformed

    private void custbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_custbtnActionPerformed
        // TODO add your handling code here:
        ManageCustomerJPanel mu = new ManageCustomerJPanel(UserProcessContainer,crs);
        UserProcessContainer.add("ManageCarRentalAgencyJPanel",mu);
        CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
        layout.next(UserProcessContainer);
    }//GEN-LAST:event_custbtnActionPerformed

    private void privatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_privatebtnActionPerformed
        // TODO add your handling code here:
        ManagePrivateProviderJPanel mpp = new ManagePrivateProviderJPanel(UserProcessContainer,crs);
        UserProcessContainer.add("ManageCarRentalAgencyJPanel",mpp);
        CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
        layout.next(UserProcessContainer);
    }//GEN-LAST:event_privatebtnActionPerformed

    private void orderbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderbtnActionPerformed
        // TODO add your handling code here:
        ManageOrderJPanel mo = new ManageOrderJPanel(UserProcessContainer,crs);
        UserProcessContainer.add("ManageCarRentalAgencyJPanel",mo);
        CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
        layout.next(UserProcessContainer);
    }//GEN-LAST:event_orderbtnActionPerformed

    private void agencybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agencybtnActionPerformed
        // TODO add your handling code here:
        ManageCarRentalAgencyJPanel mcra = new ManageCarRentalAgencyJPanel(UserProcessContainer,crs);
        UserProcessContainer.add("ManageCarRentalAgencyJPanel",mcra);
        CardLayout layout = (CardLayout)UserProcessContainer.getLayout();
        layout.next(UserProcessContainer);

    }//GEN-LAST:event_agencybtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agencybtn;
    private javax.swing.JButton btnManageNetwork;
    private javax.swing.JButton custbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTree jTree;
    private javax.swing.JLabel lblSelectedNode;
    private javax.swing.JButton orderbtn;
    private javax.swing.JButton privatebtn;
    // End of variables declaration//GEN-END:variables
}
