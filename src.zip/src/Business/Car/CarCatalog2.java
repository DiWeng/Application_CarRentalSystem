/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Car;

import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class CarCatalog2 {
    private ArrayList<Business.AgencyAccount.Car> carList;
    
    public CarCatalog2(){
        carList = new ArrayList<Business.AgencyAccount.Car>();
    }

    public ArrayList<Business.AgencyAccount.Car> getCarList() {
        return carList;
    }

    public void setCarList(ArrayList<Business.AgencyAccount.Car> carList) {
        this.carList = carList;
    }
    
    public Business.AgencyAccount.Car addCar(){
        Business.AgencyAccount.Car car = new Business.AgencyAccount.Car();
        this.carList.add(car);
        return car;
    }
    
    public void removeCar(Business.AgencyAccount.Car car){
        this.carList.remove(car);
    }
}
