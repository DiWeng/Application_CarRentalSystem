/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.User;

/**
 * 
 *
 * @author biubiu
 */
public class User {
    
    private String name;
    private int id;

    public void setId(int id) {
        this.id = id;
    }
    private static int count=1;

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        User.count = count;
    }

    public User() {
        id = count;
        count++;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
    
    
}
