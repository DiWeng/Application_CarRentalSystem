/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CustomerAccount;
import Business.AccountRole.CustomerAccountRole;
import Business.AgencyAccount.AgencyAccount;
import Business.User.User;
import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class CustomerAccountCatalog {
    private ArrayList<CustomerAccount> customerAccountList;
    public CustomerAccountCatalog() {
        customerAccountList = new ArrayList<>();
    }

    public ArrayList<CustomerAccount> getCustomerAccountList() {
        return customerAccountList;
    }
    
    public CustomerAccount authenticateUser(String username, String password){
        for (CustomerAccount ca : customerAccountList)
            if (ca.getCustomerUserName().equals(username) && ca.getCustomerPassword().equals(password)){
                return ca;
            }
        return null;
    }
    
    public CustomerAccount createCustomerAccount(String username, String password, User user, CustomerAccountRole customerAccountRole){
        CustomerAccount customerAccount = new CustomerAccount();
        customerAccount.setCustomerUserName(username);
        customerAccount.setCustomerPassword(password);
        customerAccount.setUser(user);
        customerAccount.setRole(customerAccountRole);
        customerAccountList.add(customerAccount);
        return customerAccount;
    }
    
    public CustomerAccount searchcustomerbyID(int id){
        for(CustomerAccount ca:customerAccountList){
            if(ca.getUser().getId()==id){
                return ca;
            }
        }
        return null;
    }
}
