/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

/**
 *
 * @author shirleycai
 */
public class Employee {
    String username;
    String pwd;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public Employee(String user,String pwd){
        this.username=user;
        this.pwd=pwd;
    }
    
    @Override
    public String toString(){
        return username;
    }
}
