/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import Business.AccountRole.AgencyAccountRole;
import Business.User.User;
import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class AgencyAccountCatalog {
    
    private ArrayList<AgencyAccount> agencyAccountList;
    
    public AgencyAccountCatalog() {
        agencyAccountList = new ArrayList<>();
    }

    public ArrayList<AgencyAccount> getAgencyAccountList() {
        return agencyAccountList;
    }
    
    public AgencyAccount authenticateUser(String username, String password){
        System.out.println("auth");
        for (AgencyAccount aa : agencyAccountList)
            if (aa.getAgencyUserName().equals(username) && aa.getAgencyPassword().equals(password)){
                return aa;
            }
        return null;
    }
    
    public AgencyAccount createAgencyAccount(String username, String password, User user, AgencyAccountRole agencyAccountRole){
        AgencyAccount agencyAccount = new AgencyAccount();
        agencyAccount.setAgencyUserName(username);
        agencyAccount.setAgencyPassword(password);
        agencyAccount.setRole(agencyAccountRole);
        agencyAccount.setUser(user);
        agencyAccountList.add(agencyAccount);
        return agencyAccount;
    }
}
