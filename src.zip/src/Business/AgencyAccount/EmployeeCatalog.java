/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import java.util.ArrayList;

/**
 *
 * @author shirleycai
 */
public class EmployeeCatalog {
    private ArrayList<Employee> employeeList;

    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(ArrayList<Employee> employeeList) {
        this.employeeList = employeeList;
    }
    
    public EmployeeCatalog(){
        employeeList = new ArrayList<Employee>();
        
    }
    
    public Employee addemploy(String user,String pwd){
        Employee emp = new Employee(user,pwd);
        this.employeeList.add(emp);
        return emp;
    }
    
    public void removeEmployee(Employee emp){
        this.employeeList.remove(emp);
    }
    
    public boolean verifyEmployee(String user,String pwd){
        for(Employee emp:employeeList){
            if((emp.getUsername().equals(user))&&(emp.getPwd().equals(pwd))){
                return true;
            }
        }
        return false;
    }
    
    
}
