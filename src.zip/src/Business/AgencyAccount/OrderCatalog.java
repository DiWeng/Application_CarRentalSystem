/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AgencyAccount;

import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class OrderCatalog {
    private ArrayList<Business.Order.Order> orderList;
    private int ct;

    public int getCt() {
        return ct;
    }

    public void setCt(int ct) {
        this.ct = ct;
    }
    
    public OrderCatalog(){
        orderList = new ArrayList<Business.Order.Order>();
        ct=1;
    }

    public ArrayList<Business.Order.Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(ArrayList<Business.Order.Order> orderList) {
        this.orderList = orderList;
    }
    
    public Business.Order.Order addOrder(){
        Business.Order.Order order = new Business.Order.Order();
        this.orderList.add(order);
        ct++;
        order.setOrderId(ct);
        return order;
    }
    
    public void removeOrder(Business.Order.Order order){
        this.orderList.remove(order);
    }
}
