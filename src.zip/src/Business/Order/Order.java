/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;
//修改了
import java.util.Date;

/**
 *
 * @author biubiu
 */

public class Order {
    
    private int orderId;
    private int carId;
    private int agencyId;
    private Date orderPlacedDate;
//    private int usingDate;
//    private int returnDate;
    private int startTime;
    private int endingTime;
    private int unitPrice;
    private int desposit;
    private int totalAmount;//deposit+price*(endingtime-startingtime)
    private String zipCode;
    private String orderStatus;
    private int customerId;
    private String agencyType;
    private static int ct;//count
    private String cardnum;
    private String cvv;//secu number
    private String cardexp;
    private String cardType;
    private String nameOnCard;
    private String custemail;
    
//    public int getReturnDate() {
//        return returnDate;
//    }
//
//    public void setReturnDate(int returnDate) {
//        this.returnDate = returnDate;
//    }

    public String getCustemail() {
        return custemail;
    }

    public void setCustemail(String custemail) {
        this.custemail = custemail;
    }


    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    public String getCardnum() {
        return cardnum;
    }

    public void setCardnum(String cardnum) {
        this.cardnum = cardnum;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getCardexp() {
        return cardexp;
    }

    public void setCardexp(String cardexp) {
        this.cardexp = cardexp;
    }

    public static int getCt() {
        return ct;
    }

    public static void setCt(int ct) {
        Order.ct = ct;
    }
    
    public Order(){
        orderId=ct;
        ct++;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getAgencyType() {
        return agencyType;
    }

    public void setAgencyType(String agencyType) {
        this.agencyType = agencyType;
    }
    
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(int agencyId) {
        this.agencyId = agencyId;
    }

    public Date getOrderPlacedDate() {
        return orderPlacedDate;
    }

    public void setOrderPlacedDate(Date orderPlacedDate) {
        this.orderPlacedDate = orderPlacedDate;
    }

//    public int getUsingDate() {
//        return usingDate;
//    }
//
//    public void setUsingDate(int usingDate) {
//        this.usingDate = usingDate;
//    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndingTime() {
        return endingTime;
    }

    public void setEndingTime(int endingTime) {
        this.endingTime = endingTime;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getDesposit() {
        return desposit;
    }

    public void setDesposit(int desposit) {
        this.desposit = desposit;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    
    @Override
    public String toString(){
        return String.valueOf(orderId);
    }
}
