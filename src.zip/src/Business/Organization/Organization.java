/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.AccountRole.Role;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public abstract class Organization {

    private String name;
    private int organizationID;
    private static int counter;
    
    public enum Type{
        Admin("Admin Organization"),
        Agency("Agency Organization"),
        PrivateProvider("Private Provider Organization"), 
        Customer("Customer Organization");
        
        private String value;
        
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Organization(String name) {
        this.name = name;
        organizationID = counter;
        ++counter;
    }

    public abstract ArrayList<Role> getSupportedRole();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public void setOrganizationID(int organizationID) {
        this.organizationID = organizationID;
    }

    public static int getCounter() {
        return counter;
    }

    public static void setCounter(int counter) {
        Organization.counter = counter;
    }
    
    

    @Override
    public String toString() {
        return name;
    }
    
    
}
