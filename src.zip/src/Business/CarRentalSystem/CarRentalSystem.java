/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CarRentalSystem;

import Business.AdminAccount.AdminAccountCatalog;
import Business.AgencyAccount.AgencyAccount;
import Business.AgencyAccount.AgencyAccountCatalog;
import Business.AgencyAccount.CarCatalog;
import Business.CustomerAccount.CustomerAccountCatalog;
import Business.AgencyAccount.OrderCatalog;
import Business.AgencyAccount.ParkingLocationCatalog;
import Business.CustomerAccount.CustomerAccount;
import Business.PrivateProviderAccount.PrivateProviderAccount;
import Business.PrivateProviderAccount.PrivateProviderAccountCatalog;
import Business.User.UserCatalog;
import java.util.ArrayList;

/**
 *
 * @author biubiu
 */
public class CarRentalSystem {
    private static CarRentalSystem business;
    //private final String name = "CarRentalSystem";
    //private WorkQueue workQueue;
    private ArrayList<Network> networkList;
    private AdminAccountCatalog adminAccountCatalog;

    public static CarRentalSystem getBusiness() {
        return business;
    }

    public static void setBusiness(CarRentalSystem business) {
        CarRentalSystem.business = business;
    }

    public AdminAccountCatalog getAdminAccountCatalog() {
        return adminAccountCatalog;
    }

    public void setAdminAccountCatalog(AdminAccountCatalog adminAccountCatalog) {
        this.adminAccountCatalog = adminAccountCatalog;
    }

    

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    public void setNetworkList(ArrayList<Network> networkList) {
        this.networkList = networkList;
    }
    

    

    

    
    
    public static CarRentalSystem getInstance(){
        if(business==null){
            System.out.println("bbb");
            business=new CarRentalSystem();
        }
        return business;
    }
    
    public Network createAndAddNetwork(){
        Network network=new Network();
        networkList.add(network);
        return network;
    }
    
    
    
    public CarRentalSystem(){
        //super(null);
        networkList=new ArrayList<Network>();
        adminAccountCatalog = new AdminAccountCatalog();
        
        
    }
    
    
    public boolean uniqueuser(String user){
        for(Network nt:networkList){
        for(CustomerAccount ca: nt.getCusomerAccountCatalog().getCustomerAccountList()){
            if(ca.getCustomerUserName().equals(user)){
                return false;
            }
        }
         for(AgencyAccount aa: nt.getAgencyAccountCatalog().getAgencyAccountList()){
            if(aa.getAgencyUserName().equals(user)){
                return false;
            }
        }
          for(PrivateProviderAccount ppa: nt.getPrivateProviderAccountCatalog().getPrivateProviderAccountList()){
            if(ppa.getUsername().equals(user)){
                return false;
            }
          } 
        }
        return true;
    }
    
    public boolean checknetwork(String net){
        for(Network nt:networkList){
            if(nt.getName().equals(net)){
                return false;
            }
        }
        return true;
    }
   
    
    
}
