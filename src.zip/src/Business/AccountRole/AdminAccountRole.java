/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AccountRole;

import Business.AdminAccount.AdminAccount;
import Business.CarRentalSystem.CarRentalSystem;
import Business.Organization.Organization;
//import UserInterface.AdministrativeRole.AdminWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author biubiu
 */
public class AdminAccountRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, AdminAccount account, Organization organization, CarRentalSystem carRentalSystem) {
        //return new AdminWorkAreaJPanel(userProcessContainer, Business.getInstance());
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    
}
