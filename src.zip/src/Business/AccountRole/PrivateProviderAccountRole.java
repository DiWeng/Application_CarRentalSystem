/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AccountRole;

import Business.Organization.Organization;
import Business.AdminAccount.AdminAccount;
import Business.CarRentalSystem.CarRentalSystem;
//import UserInterface.DoctorRole.DoctorWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class PrivateProviderAccountRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, AdminAccount account, Organization organization, CarRentalSystem carRentalSystem) {
        throw new UnsupportedOperationException("Not supported yet.");
        //return new DoctorWorkAreaJPanel(userProcessContainer, account, (FinanceOrganization)organization, business);
    }
    
    
}
