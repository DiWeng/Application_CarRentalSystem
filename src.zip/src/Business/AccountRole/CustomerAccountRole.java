/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AccountRole;

import Business.Organization.Organization;
import Business.AdminAccount.AdminAccount;
import Business.CarRentalSystem.CarRentalSystem;
import Business.User.User;
//import UserInterface.LabAssistantRole.LabAssistantWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class CustomerAccountRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, AdminAccount account, Organization organization, CarRentalSystem carRentalSystem) {
        throw new UnsupportedOperationException("Not supported yet.");
        //return new LabAssistantWorkAreaJPanel(userProcessContainer, account, organization, business);
    }
    
}
